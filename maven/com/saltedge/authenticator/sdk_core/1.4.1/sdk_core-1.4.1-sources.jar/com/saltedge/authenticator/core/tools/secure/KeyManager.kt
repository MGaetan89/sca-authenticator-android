/*
 * Copyright (c) 2021 Salt Edge Inc.
 */
@file:Suppress("DEPRECATION")

package com.saltedge.authenticator.core.tools.secure

import android.annotation.SuppressLint
import android.annotation.TargetApi
import android.content.Context
import android.os.Build
import android.security.KeyPairGeneratorSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import androidx.annotation.RequiresApi
import com.saltedge.authenticator.core.model.ConnectionAbs
import com.saltedge.authenticator.core.model.RichConnection
import timber.log.Timber
import java.math.BigInteger
import java.security.*
import java.util.*
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.security.auth.x500.X500Principal

private const val ANDROID_KEYSTORE = "AndroidKeyStore"

object KeyManager : KeyManagerAbs {

    private var androidKeyStore: KeyStore? = null

    init {
        loadKeyStore()
    }

    /**
     * Creates new or replace existing RSA key pairs with new one by the given alias
     *
     * @param alias - the alias name
     * @return KeyPair object
     */
    override fun createOrReplaceRsaKeyPair(context: Context, alias: String): KeyPair? {
        return try {
            deleteKeyPairIfExist(alias = alias)
            generateRsaKeyPair(context = context, alias = alias)
        } catch (e: Exception) {
            Timber.e(e, "Error creating/replacing RSA Key Pair for alias: $alias")
            null
        }
    }

    /**
     * Checks if key pair is exist by the given alias
     *
     * @param alias - the alias name
     * @return boolean, true if key store contains alias
     */
    override fun keyEntryExist(alias: String): Boolean {
        return try {
            androidKeyStore?.containsAlias(alias) ?: false
        } catch (e: KeyStoreException) {
            Timber.e(e, "Error checking key existence for alias: $alias")
            false
        }
    }

    /**
     * Get key store aliases
     *
     * @return list of aliases
     */
    override fun getKeyStoreAliases(): List<String> {
        return try {
            val aliases: Enumeration<String> = androidKeyStore?.aliases() ?: return emptyList()
            val result = ArrayList<String>()
            while (aliases.hasMoreElements()) result.add(aliases.nextElement())
            result
        } catch (e: KeyStoreException) {
            Timber.e(e, "Error fetching key store aliases")
            emptyList()
        }
    }

    /**
     * Get AES secret key by the given alias
     *
     * @return SecretKey object
     */
    override fun getSecretKey(alias: String): Key? {
        return try {
            if (androidKeyStore?.containsAlias(alias) != true) {
                Timber.e("Secret key for alias '$alias' does not exist in KeyStore.")
                return null
            }
            androidKeyStore?.getKey(alias, null)
        } catch (e: Exception) {
            Timber.e(e, "Error retrieving secret key for alias: $alias")
            null
        }
    }

    /**
     * Get RSA key pair by the given alias
     *
     * @param alias - the alias name
     * @return KeyPair object
     */
    override fun getKeyPair(alias: String): KeyPair? {
        return try {
            val store = androidKeyStore ?: return null
            (store.getKey(alias, null) as? PrivateKey)?.let { privateKey ->
                KeyPair(store.getCertificate(alias).publicKey, privateKey)
            }
        } catch (e: Exception) {
            Timber.e(e, "Error retrieving key pair for alias: $alias")
            null
        }
    }

    /**
     * Delete key pairs identified by list of guids
     *
     * @param guids - list of guids
     * @return list of guids
     */
    override fun deleteKeyPairsIfExist(guids: List<String>) = guids.forEach { deleteKeyPairIfExist(it) }

    /**
     * Delete key pair identified by the given alias from Android Keystore
     *
     * @param alias - the alias name
     */
    override fun deleteKeyPairIfExist(alias: String) {
        try {
            androidKeyStore?.let { if (it.containsAlias(alias)) it.deleteEntry(alias) }
        } catch (e: KeyStoreException) {
            Timber.e(e, "Error deleting key pair for alias: $alias")
        }
    }

    /**
     * Creates or replace a AES (AES/GCM/NoPadding) secret key
     *
     * @param alias - the alias name
     * @return AES SecretKey object
     */
    fun createOrReplaceAesKey(alias: String): SecretKey? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return null
        return try {
            val mKeyGenerator = KeyGenerator.getInstance(
                KeyProperties.KEY_ALGORITHM_AES,
                ANDROID_KEYSTORE
            )
            val purposes = KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            val spec = KeyGenParameterSpec.Builder(alias, purposes)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(false)
                .build()
            mKeyGenerator.init(spec)
            mKeyGenerator.generateKey()
        } catch (e: Exception) {
            Timber.e(e)
            null
        }
    }

    /**
     * Creates or replace a AES secret key, designated for biometric tools
     *
     * @param alias - the alias name
     * @return AES SecretKey object
     */
    @RequiresApi(Build.VERSION_CODES.M)
    override fun createOrReplaceAesBiometricKey(alias: String): SecretKey? {
        return try {
            val builder = KeyGenParameterSpec.Builder(
                alias,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
            builder.setBlockModes(KeyProperties.BLOCK_MODE_CBC)
            builder.setUserAuthenticationRequired(true)
            builder.setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_PKCS7)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                builder.setInvalidatedByBiometricEnrollment(true)
            }
            val mKeyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
            mKeyGenerator.init(builder.build())
            mKeyGenerator.generateKey()
        } catch (e: Exception) {
            Timber.e(e)
            null
        }
    }

    /**
     *  Get related RSA keys for connection
     *
     *  @param connection Connection
     *  @param addProviderKey flag what indicates to add provider public key or not
     *  @return RichConnection
     */
    override fun enrichConnection(connection: ConnectionAbs, addProviderKey: Boolean): RichConnection? {
        val appRsaPair = getKeyPair(alias = connection.guid) ?: return null
        val providerRsaPublic = if (addProviderKey) {
            connection.providerRsaPublicKeyPem.pemToPublicKey(algorithm = KeyAlgorithm.RSA)
        } else null
        return RichConnection(connection, appRsaPair.private, providerRsaPublic)
    }

    /**
     * Create new RSA key pair by the given alias
     *
     * @param alias - the alias name
     * @return KeyPair object
     */
    fun generateRsaKeyPair(context: Context, alias: String): KeyPair? {
        return (if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            initAsymmetricKeyGenerator(context = context, alias = alias)
        } else {
            initRsaKeyGenerator(alias = alias)
        }).generateKeyPair()
    }

    /**
     * Initialize old type KeyPairGenerator
     * Designated for Android version less than SDK23
     *
     * @param context Application Context
     * @param alias the alias name
     * @return generator KeyPairGenerator
     */
    @Suppress("DEPRECATION")
    private fun initAsymmetricKeyGenerator(context: Context, alias: String): KeyPairGenerator {
        val builder = KeyPairGeneratorSpec.Builder(context)
            .setAlias(alias)
            .setSerialNumber(BigInteger.ONE)
            .setSubject(X500Principal("CN=${alias} CA Certificate"))
            .setStartDate(Calendar.getInstance().time)
            .setEndDate((Calendar.getInstance().apply { add(Calendar.YEAR, 20) }).time)
        return  KeyPairGenerator.getInstance(KeyAlgorithm.RSA, ANDROID_KEYSTORE).apply {
            initialize(builder.build())
        }
    }

    /**
     * Initialize KeyPairGenerator for RSA
     * Designated for Android version greater than or equal to SDK23
     *
     * @param alias the alias name
     * @return generator KeyPairGenerator
     */
    @TargetApi(Build.VERSION_CODES.M)
    private fun initRsaKeyGenerator(alias: String): KeyPairGenerator {
        val builder = KeyGenParameterSpec.Builder(
            alias,
            KeyProperties.PURPOSE_ENCRYPT
                or KeyProperties.PURPOSE_DECRYPT
                or KeyProperties.PURPOSE_SIGN
        )
        builder.setDigests(KeyProperties.DIGEST_SHA256)
        builder.setKeySize(DEFAULT_KEY_SIZE)
        builder.setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1)
        builder.setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_RSA_PKCS1)
        return  KeyPairGenerator.getInstance(KeyAlgorithm.RSA, ANDROID_KEYSTORE).apply {
            initialize(builder.build())
        }
    }

    /**
     * Load/Init KeyStore
     */
    private fun loadKeyStore() {
        try {
            androidKeyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply {
                load(null)
            }
        } catch (e: Exception) {
            Timber.e(e, "Error loading Android KeyStore")
        }
    }
}

interface KeyManagerAbs {
    fun createOrReplaceRsaKeyPair(context: Context, alias: String): KeyPair?
    fun keyEntryExist(alias: String): Boolean
    fun getKeyStoreAliases(): List<String>
    fun getSecretKey(alias: String): Key?
    fun getKeyPair(alias: String): KeyPair?
    fun deleteKeyPairsIfExist(guids: List<String>)
    fun deleteKeyPairIfExist(alias: String)
    @SuppressLint("NewApi") fun createOrReplaceAesBiometricKey(alias: String): SecretKey?
    fun enrichConnection(connection: ConnectionAbs, addProviderKey: Boolean = true): RichConnection?
}