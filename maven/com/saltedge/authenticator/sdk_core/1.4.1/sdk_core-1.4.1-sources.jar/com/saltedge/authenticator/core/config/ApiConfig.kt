/*
 * Copyright (c) 2021 Salt Edge Inc.
 */
package com.saltedge.authenticator.core.config

import android.content.Context
import com.saltedge.authenticator.core.tools.buildUserAgent

const val DEFAULT_RETURN_URL = "authenticator://oauth/redirect"

abstract class ApiConfig {
    /**
     * Url where WebView will be redirected on enrollment finish
     */
    var authenticationReturnUrl: String = DEFAULT_RETURN_URL
    var userAgentInfo = ""
        private set
    var debugLogLevel = false

    /**
     * Initialize SDK
     *
     * @param context of Application
     */
    fun setupConfig(
        context: Context,
        authenticationReturnUrl: String = DEFAULT_RETURN_URL,
        debugLogLevel: Boolean = false
    ) {
        this.userAgentInfo = buildUserAgent(context)
        this.authenticationReturnUrl = authenticationReturnUrl
        this.debugLogLevel = debugLogLevel
    }

    fun isReturnToUrl(url: String): Boolean = url.startsWith(authenticationReturnUrl)
}

